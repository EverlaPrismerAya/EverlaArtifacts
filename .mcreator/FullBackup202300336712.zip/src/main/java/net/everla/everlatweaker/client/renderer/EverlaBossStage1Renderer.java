

package net.everla.everlatweaker.client.renderer;




public class EverlaBossStage1Renderer extends MobRenderer<EverlaBossStage1Entity, ModelPlayerModel<EverlaBossStage1Entity>> {

	public EverlaBossStage1Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(EverlaBossStage1Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlaprismer.png");
	}



}
