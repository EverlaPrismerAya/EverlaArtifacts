

package net.everla.everlatweaker.client.renderer;




public class EverlaBossGFB1Renderer extends MobRenderer<EverlaBossGFB1Entity, ModelPlayerModel<EverlaBossGFB1Entity>> {

	public EverlaBossGFB1Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 1.8f);


		this.addLayer(new RenderLayer<EverlaBossGFB1Entity, ModelPlayerModel<EverlaBossGFB1Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("everlatweaker:textures/entities/gfboverlay.png");

@Override public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light,
EverlaBossGFB1Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
}		});
	}


	@Override public ResourceLocation getTextureLocation(EverlaBossGFB1Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlagfb.png");
	}



}
