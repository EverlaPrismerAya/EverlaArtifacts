
package net.everla.everlatweaker.entity;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.sounds.SoundEvent;

import javax.annotation.Nullable;




public class EverlaBossGFBFinalEntity extends Monster  {


	private final ServerBossEvent bossInfo = new ServerBossEvent(this.getDisplayName(),
		ServerBossEvent.BossBarColor.WHITE, ServerBossEvent.BossBarOverlay.PROGRESS);

	public EverlaBossGFBFinalEntity(PlayMessages.SpawnEntity packet, Level world) {
    	this(EverlatweakerModEntities.EVERLA_BOSS_GFB_FINAL.get(), world);
    }

	public EverlaBossGFBFinalEntity(EntityType<EverlaBossGFBFinalEntity> type, Level world) {
    	super(type, world);
		setMaxUpStep(0f);
		xpReward = 0;
		setNoAi(true);

        	setCustomName(Component.literal("EverlaPrismerAya"));
        	setCustomNameVisible(true);

			setPersistenceRequired();


		this.moveControl = new FlyingMoveControl(this, 10, true);

	}

	@Override public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}


	@Override protected PathNavigation createNavigation(Level world) {
		return new FlyingPathNavigation(this, world);
	}



	@Override public MobType getMobType() {
		return MobType.UNDEAD;
	}

	@Override public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}






	@Override public SoundEvent getHurtSound(DamageSource ds) {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.break"));
	}

	@Override public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("everlatweaker:everladeath"));
	}


	@Override public boolean causeFallDamage(float l, float d, DamageSource source) {

			return false;
	}

	@Override public boolean hurt(DamageSource damagesource, float amount) {
			if (damagesource.is(DamageTypes.IN_FIRE))
				return false;
			if (damagesource.getDirectEntity() instanceof AbstractArrow)
				return false;
			if (damagesource.getDirectEntity() instanceof Player)
				return false;
			if (damagesource.getDirectEntity() instanceof ThrownPotion || damagesource.getDirectEntity() instanceof AreaEffectCloud)
				return false;
			if (damagesource.is(DamageTypes.FALL))
				return false;
			if (damagesource.is(DamageTypes.CACTUS))
				return false;
			if (damagesource.is(DamageTypes.DROWN))
				return false;
			if (damagesource.is(DamageTypes.LIGHTNING_BOLT))
				return false;
			if (damagesource.is(DamageTypes.EXPLOSION))
				return false;
			if (damagesource.is(DamageTypes.TRIDENT))
				return false;
			if (damagesource.is(DamageTypes.FALLING_ANVIL))
				return false;
			if (damagesource.is(DamageTypes.DRAGON_BREATH))
				return false;
			if (damagesource.is(DamageTypes.WITHER))
				return false;
			if (damagesource.is(DamageTypes.WITHER_SKULL))
				return false;
		return super.hurt(damagesource, amount);
	}











	@Override public boolean checkSpawnObstruction(LevelReader world) {
		return world.isUnobstructed(this);
	}

	@Override public boolean canBreatheUnderwater() {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		return         true
;
	}


	@Override public boolean isPushable() {
		return false;
	}

   	@Override protected void doPush(Entity entityIn) {
   	}

   	@Override protected void pushEntities() {
   	}


	@Override public boolean canChangeDimensions() {
		return false;
	}

	@Override public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		this.bossInfo.addPlayer(player);
	}

	@Override public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		this.bossInfo.removePlayer(player);
	}

	@Override public void customServerAiStep() {
		super.customServerAiStep();
		this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
	}



	@Override protected void checkFallDamage(double y, boolean onGroundIn, BlockState state, BlockPos pos) {
   	}

   	@Override public void setNoGravity(boolean ignored) {
		super.setNoGravity(true);
	}

    public void aiStep() {
		super.aiStep();

		this.setNoGravity(true);
	}

	public static void init() {

	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0);
		builder = builder.add(Attributes.MAX_HEALTH, 135);
		builder = builder.add(Attributes.ARMOR, 40);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 0);
		builder = builder.add(Attributes.FOLLOW_RANGE, 32);

		builder = builder.add(Attributes.KNOCKBACK_RESISTANCE, 288);


		builder = builder.add(Attributes.FLYING_SPEED, 0);

		builder = builder.add(ForgeMod.SWIM_SPEED.get(), 0);


		return builder;
	}

}
