package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class GodslayerChestFuncProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST):ItemStack.EMPTY).getItem() == EverlatweakerModItems.GODSLAYER_ARMOR_CHESTPLATE.get()) {if (!((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST):ItemStack.EMPTY).getOrCreateTag().getBoolean("Equipped")==true)) {(entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST):ItemStack.EMPTY).getOrCreateTag().putBoolean("Equipped", true);}}
}
}
