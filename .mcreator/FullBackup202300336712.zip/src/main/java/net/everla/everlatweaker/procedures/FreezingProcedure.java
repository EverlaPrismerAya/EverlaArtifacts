package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class FreezingProcedure {
public static void execute(
LevelAccessor world,
Entity entity
) {
if(
entity == null
) return ;
entity.setTicksFrozen(150);entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.FREEZE)), 5);
}
}
