

package net.everla.everlatweaker.client.renderer;




public class EverlaBossStage35Renderer extends MobRenderer<EverlaBossStage35Entity, ModelBulletModel<EverlaBossStage35Entity>> {

	public EverlaBossStage35Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(EverlaBossStage35Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
