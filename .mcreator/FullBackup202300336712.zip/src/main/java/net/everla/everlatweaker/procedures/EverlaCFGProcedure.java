package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


@Mod.EventBusSubscriber public class EverlaCFGProcedure {
@SubscribeEvent public static void onWorldLoad(net.minecraftforge.event.level.LevelEvent.Load event) {
execute(event);
}
public static void execute(
) {
execute(null);
}
private static void execute(
@Nullable Event event
) {
if (!) {}if (ModList.get().isLoaded("avaritia")) {}else{}if (ModList.get().isLoaded("projecte")) {}else{}if (ModList.get().isLoaded("torcherino")) {}else{}if (ModList.get().isLoaded("forge")) {}else{}if (ModList.get().isLoaded("estrogen")) {}else{}
}
}
