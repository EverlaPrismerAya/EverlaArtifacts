
package net.everla.everlatweaker.potion;

public class DownsSyndromeMobEffect extends MobEffect {
public DownsSyndromeMobEffect() {
super(MobEffectCategory.HARMFUL, -26113);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.downs_syndrome";
}
@Override public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
super.removeAttributeModifiers(entity, attributeMap, amplifier);
DownsSyndromeInstaKillProcedure.execute(entity.level(),entity);
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
}