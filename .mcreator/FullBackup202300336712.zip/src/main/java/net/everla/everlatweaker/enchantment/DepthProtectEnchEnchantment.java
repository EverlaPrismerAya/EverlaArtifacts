
package net.everla.everlatweaker.enchantment;

public class DepthProtectEnchEnchantment extends Enchantment {

	public DepthProtectEnchEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.ARMOR_HEAD, slots);
	}






		@Override public boolean isTreasureOnly() {
			return true;
		}



		@Override public boolean isDiscoverable() {
			return false;
		}

		@Override public boolean isTradeable() {
			return false;
		}
}
