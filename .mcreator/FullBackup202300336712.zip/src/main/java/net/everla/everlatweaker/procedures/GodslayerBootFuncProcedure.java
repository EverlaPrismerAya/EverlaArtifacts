package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class GodslayerBootFuncProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET):ItemStack.EMPTY).getItem() == EverlatweakerModItems.GODSLAYER_ARMOR_BOOTS.get()) {if (!((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET):ItemStack.EMPTY).getOrCreateTag().getBoolean("Equipped")==true)) {(entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET):ItemStack.EMPTY).getOrCreateTag().putBoolean("Equipped", true);}}
}
}
