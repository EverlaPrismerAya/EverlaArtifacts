

package net.everla.everlatweaker.client.renderer;




public class WardenBlastRenderer extends MobRenderer<WardenBlastEntity, ModelBulletModel<WardenBlastEntity>> {

	public WardenBlastRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(WardenBlastEntity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
