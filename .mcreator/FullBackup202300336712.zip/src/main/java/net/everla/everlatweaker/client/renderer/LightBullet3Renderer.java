

package net.everla.everlatweaker.client.renderer;




public class LightBullet3Renderer extends MobRenderer<LightBullet3Entity, ModelBulletModel<LightBullet3Entity>> {

	public LightBullet3Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(LightBullet3Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
