

package net.everla.everlatweaker.client.renderer;




public class EverlaBossStage0Renderer extends MobRenderer<EverlaBossStage0Entity, ModelPlayerModel<EverlaBossStage0Entity>> {

	public EverlaBossStage0Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(EverlaBossStage0Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlaprismer.png");
	}



}
