package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class HyperhotLavaBurnProcedure {
public static void execute(
LevelAccessor world,
double x,
double y,
double z,
Entity entity
) {
if(
entity == null
) return ;
if (world.getBiome(BlockPos.containing(x,y,z)).is(new ResourceLocation("everlatweaker:thorium_planet"))) {if ((world.getBlockState(BlockPos.containing(x,y,z))).getBlock() == Blocks.LAVA) {entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.BAD_RESPAWN_POINT)), (float)(((entity instanceof LivingEntity _livEnt? _livEnt.getMaxHealth():-1)/ 10)*(1+(entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(EverlatweakerModMobEffects.HYPERHOT_LAVA.get()) ?
_livEnt.getEffect(EverlatweakerModMobEffects.HYPERHOT_LAVA.get()).getAmplifier() : 0))));}if ((world.getBlockState(BlockPos.containing(x,y,z))).getBlock() == Blocks.LAVA) {entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.BAD_RESPAWN_POINT)), (float)(((entity instanceof LivingEntity _livEnt? _livEnt.getMaxHealth():-1)/ 10)*(1+(entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(EverlatweakerModMobEffects.HYPERHOT_LAVA.get()) ?
_livEnt.getEffect(EverlatweakerModMobEffects.HYPERHOT_LAVA.get()).getAmplifier() : 0))));}}
}
}
