

package net.everla.everlatweaker.client.renderer;




public class BulletHellRenderer extends MobRenderer<BulletHellEntity, ModelBulletModel<BulletHellEntity>> {

	public BulletHellRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(BulletHellEntity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
