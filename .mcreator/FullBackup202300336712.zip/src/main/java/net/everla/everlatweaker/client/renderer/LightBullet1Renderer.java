

package net.everla.everlatweaker.client.renderer;




public class LightBullet1Renderer extends MobRenderer<LightBullet1Entity, ModelBulletModel<LightBullet1Entity>> {

	public LightBullet1Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(LightBullet1Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
