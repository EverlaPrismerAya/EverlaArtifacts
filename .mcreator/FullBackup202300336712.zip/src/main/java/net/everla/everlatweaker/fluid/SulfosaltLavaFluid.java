
package net.everla.everlatweaker.fluid;

public abstract class SulfosaltLavaFluid extends ForgeFlowingFluid {
public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(
() -> EverlatweakerModFluidTypes.SULFOSALT_LAVA_TYPE.get(),
() -> EverlatweakerModFluids.SULFOSALT_LAVA.get(),
() -> EverlatweakerModFluids.FLOWING_SULFOSALT_LAVA.get())
.explosionResistance(7200f)
.tickRate(30)
.levelDecreasePerBlock(2)
.slopeFindDistance(2)
.bucket(() -> EverlatweakerModItems.SULFOSALT_LAVA_BUCKET.get())
.block(() -> (LiquidBlock) EverlatweakerModBlocks.SULFOSALT_LAVA.get());
private SulfosaltLavaFluid() {
super(PROPERTIES);
}
public static class Source extends SulfosaltLavaFluid {
public int getAmount(FluidState state) {
return 8;
}
public boolean isSource(FluidState state) {
return true;
}
}
public static class Flowing extends SulfosaltLavaFluid {
protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
super.createFluidStateDefinition(builder);
builder.add(LEVEL);
}
public int getAmount(FluidState state) {
return state.getValue(LEVEL);
}
public boolean isSource(FluidState state) {
return false;
}
}
}
