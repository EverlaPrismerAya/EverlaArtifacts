

package net.everla.everlatweaker.client.renderer;




public class LightBullet2Renderer extends MobRenderer<LightBullet2Entity, ModelBulletModel<LightBullet2Entity>> {

	public LightBullet2Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(LightBullet2Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
