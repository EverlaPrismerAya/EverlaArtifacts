
package net.everla.everlatweaker.potion;

public class NoMoreFlightMobEffect extends MobEffect {
public NoMoreFlightMobEffect() {
super(MobEffectCategory.BENEFICIAL, -13434625);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.no_more_flight";
}
@Override public void applyEffectTick(LivingEntity entity, int amplifier) {
NoMoreFlightBroProcedure.execute(entity.level(),entity);
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
}