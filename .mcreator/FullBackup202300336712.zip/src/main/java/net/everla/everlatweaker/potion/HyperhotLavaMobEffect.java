
package net.everla.everlatweaker.potion;

public class HyperhotLavaMobEffect extends MobEffect {
public HyperhotLavaMobEffect() {
super(MobEffectCategory.BENEFICIAL, -6750208);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.hyperhot_lava";
}
@Override public void applyEffectTick(LivingEntity entity, int amplifier) {
HyperhotLavaBurnProcedure.execute(entity.level(),entity.getX(),entity.getY(),entity.getZ(),entity);
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
}