

package net.everla.everlatweaker.item;

import net.minecraft.world.entity.ai.attributes.Attributes;

public class MetalPipeItem extends AxeItem {
public MetalPipeItem () {
super( new Tier() {
public int getUses() {
return 4444;
}
public float getSpeed() {
return 2f;
}
public float getAttackDamageBonus() {
return 28f;
}
public int getLevel() {
return 4;
}
public int getEnchantmentValue() {
return 20;
}
public Ingredient getRepairIngredient() {
return Ingredient.of(new ItemStack(EverlatweakerModItems.AURIC_INGOT.get()));
}
},
1,-0.8f,
new Item.Properties()
.fireResistant()
);
}
@Override public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
MetalPipeNoiseProcedure.execute(entity.level(),entity.getX(),entity.getY(),entity.getZ(),entity);
return retval;
}
@Override public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
super.appendHoverText(itemstack, world, list, flag);
list.add(Component.literal("text.metalpipe.desc0"));
list.add(Component.literal("text.metalpipe.desc"));
}
@Override public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
super.inventoryTick(itemstack, world, entity, slot, selected);
if (selected)
MetalPipeAttributeProcedure.execute(entity);
}
}
