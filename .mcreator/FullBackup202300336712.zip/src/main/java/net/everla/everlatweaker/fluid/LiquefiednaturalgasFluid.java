
package net.everla.everlatweaker.fluid;

public abstract class LiquefiednaturalgasFluid extends ForgeFlowingFluid {
public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(
() -> EverlatweakerModFluidTypes.LIQUEFIEDNATURALGAS_TYPE.get(),
() -> EverlatweakerModFluids.LIQUEFIEDNATURALGAS.get(),
() -> EverlatweakerModFluids.FLOWING_LIQUEFIEDNATURALGAS.get())
.explosionResistance(7200f)
.bucket(() -> EverlatweakerModItems.LIQUEFIEDNATURALGAS_BUCKET.get())
.block(() -> (LiquidBlock) EverlatweakerModBlocks.LIQUEFIEDNATURALGAS.get());
private LiquefiednaturalgasFluid() {
super(PROPERTIES);
}
public static class Source extends LiquefiednaturalgasFluid {
public int getAmount(FluidState state) {
return 8;
}
public boolean isSource(FluidState state) {
return true;
}
}
public static class Flowing extends LiquefiednaturalgasFluid {
protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
super.createFluidStateDefinition(builder);
builder.add(LEVEL);
}
public int getAmount(FluidState state) {
return state.getValue(LEVEL);
}
public boolean isSource(FluidState state) {
return false;
}
}
}
