
package net.everla.everlatweaker.potion;

public class DepthProtectMobEffect extends MobEffect {
public DepthProtectMobEffect() {
super(MobEffectCategory.BENEFICIAL, -13424345);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.depth_protect";
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
}