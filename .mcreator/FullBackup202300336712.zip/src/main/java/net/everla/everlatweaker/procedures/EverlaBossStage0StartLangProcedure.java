package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class EverlaBossStage0StartLangProcedure {
public static void execute(
LevelAccessor world,
Entity entity
) {
if(
entity == null
) return ;
{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tellraw @a[distance=..128] {\"translate\":\"text.everlatweaker.bosstext0\",\"fallback\":\"EverlaPrismerAya joined the game\",\"color\":\"yellow\"}");
}
}EverlatweakerMod.queueServerWork(20, () -> {
{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tellraw @a[distance=..128] {\"translate\":\"text.everlatweaker.bosstext1\",\"fallback\":\"<EverlaPrismerAya> Hello.\"}");
}
}EverlatweakerMod.queueServerWork(60, () -> {
{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tellraw @a[distance=..128] {\"translate\":\"text.everlatweaker.bosstext2\",\"fallback\":\"<EverlaPrismerAya> You finally comes here.\"}");
}
}EverlatweakerMod.queueServerWork(60, () -> {
{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tellraw @a[distance=..128] {\"translate\":\"text.everlatweaker.bosstext3\",\"fallback\":\"<EverlaPrismerAya> Now,It's the time to start your final challenge.\"}");
}
}EverlatweakerMod.queueServerWork(10, () -> {
{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "summon everlatweaker:everla_boss_stage_1");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "effect give @e[type=everlatweaker:everla_boss_stage_1,distance=..60] resistance 5 255 true");
}
}if(!entity.level().isClientSide()) entity.discard();
});
});
});
});
}
}
