
package net.everla.everlatweaker.potion;

public class GodSlayerDMGMobEffect extends MobEffect {
public GodSlayerDMGMobEffect() {
super(MobEffectCategory.BENEFICIAL, -52225);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.god_slayer_dmg";
}
@Override public void applyEffectTick(LivingEntity entity, int amplifier) {
GodSlayerDMGActProcedure.execute(entity.level(),entity);
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
@Override public void initializeClient(java.util.function.Consumer<IClientMobEffectExtensions> consumer) {
consumer.accept(new IClientMobEffectExtensions() {
@Override public boolean isVisibleInInventory(MobEffectInstance effect) {
return false;
}
@Override public boolean renderInventoryText(MobEffectInstance instance, EffectRenderingInventoryScreen<?> screen, GuiGraphics guiGraphics, int x, int y, int blitOffset) {
return false;
}
@Override public boolean isVisibleInGui(MobEffectInstance effect) {
return false;
}
});
}
}