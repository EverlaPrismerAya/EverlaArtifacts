

package net.everla.everlatweaker.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class DeepslateAuricOreBlock extends
Block
{
public DeepslateAuricOreBlock() {
super( BlockBehaviour.Properties.of()
.instrument(NoteBlockInstrument.BASEDRUM)
.mapColor(MapColor.GOLD)
.sound(SoundType.ANCIENT_DEBRIS)
.strength(45f, 1200f)
.lightLevel(s -> 2)
.requiresCorrectToolForDrops()
.speedFactor(1.4f)
.jumpFactor(1.5f)
);
}
@Override public void appendHoverText(ItemStack itemstack, BlockGetter world, List<Component> list, TooltipFlag flag) {
super.appendHoverText(itemstack, world, list, flag);
list.add(Component.literal("auric.desc"));
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public boolean isSignalSource(BlockState state) {
return true;
}
@Override public int getSignal(BlockState blockstate, BlockGetter blockAccess, BlockPos pos, Direction direction) {
return 2;
}
@Override
public boolean canConnectRedstone(BlockState state, BlockGetter world, BlockPos pos, Direction side) {
return true;
}
@Override public boolean canHarvestBlock(BlockState state, BlockGetter world, BlockPos pos, Player player) {
if(player.getInventory().getSelected().getItem() instanceof
PickaxeItem
tieredItem)
return tieredItem.getTier().getLevel() >= 4;
return false;
}
}