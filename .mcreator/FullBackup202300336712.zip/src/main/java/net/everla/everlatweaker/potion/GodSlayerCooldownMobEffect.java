
package net.everla.everlatweaker.potion;

public class GodSlayerCooldownMobEffect extends MobEffect {
public GodSlayerCooldownMobEffect() {
super(MobEffectCategory.BENEFICIAL, -10092442);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.god_slayer_cooldown";
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
}