

package net.everla.everlatweaker.block;

import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class LiquidNitrogenBlock extends LiquidBlock {
public LiquidNitrogenBlock() {
super(() -> EverlatweakerModFluids.LIQUID_NITROGEN.get(),
BlockBehaviour.Properties.of()
.mapColor(MapColor.WATER)
.strength(7200f)
.noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable()
);
}
@Override public void entityInside(BlockState blockstate, Level world, BlockPos pos, Entity entity) {
super.entityInside(blockstate, world, pos, entity);
LiquidNitrogenFreezeDMGProcedure.execute(entity);
}
}