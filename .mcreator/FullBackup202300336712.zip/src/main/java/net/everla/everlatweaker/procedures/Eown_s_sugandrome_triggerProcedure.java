package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class Eown_s_sugandrome_triggerProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
if(entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
_entity.addEffect(new MobEffectInstance(EverlatweakerModMobEffects.DOWNS_SYNDROME.get(),48000,0, true, true));
}
}
