package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class GodslayerLegFuncProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS):ItemStack.EMPTY).getItem() == EverlatweakerModItems.GODSLAYER_ARMOR_LEGGINGS.get()) {if (!((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS):ItemStack.EMPTY).getOrCreateTag().getBoolean("Equipped")==true)) {(entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS):ItemStack.EMPTY).getOrCreateTag().putBoolean("Equipped", true);}}
}
}
