
package net.everla.everlatweaker.fluid;

public abstract class LiquidNitrogenFluid extends ForgeFlowingFluid {
public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(
() -> EverlatweakerModFluidTypes.LIQUID_NITROGEN_TYPE.get(),
() -> EverlatweakerModFluids.LIQUID_NITROGEN.get(),
() -> EverlatweakerModFluids.FLOWING_LIQUID_NITROGEN.get())
.explosionResistance(7200f)
.bucket(() -> EverlatweakerModItems.LIQUID_NITROGEN_BUCKET.get())
.block(() -> (LiquidBlock) EverlatweakerModBlocks.LIQUID_NITROGEN.get());
private LiquidNitrogenFluid() {
super(PROPERTIES);
}
public static class Source extends LiquidNitrogenFluid {
public int getAmount(FluidState state) {
return 8;
}
public boolean isSource(FluidState state) {
return true;
}
}
public static class Flowing extends LiquidNitrogenFluid {
protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
super.createFluidStateDefinition(builder);
builder.add(LEVEL);
}
public int getAmount(FluidState state) {
return state.getValue(LEVEL);
}
public boolean isSource(FluidState state) {
return false;
}
}
}
