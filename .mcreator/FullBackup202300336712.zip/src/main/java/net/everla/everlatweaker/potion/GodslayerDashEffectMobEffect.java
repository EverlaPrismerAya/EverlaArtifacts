
package net.everla.everlatweaker.potion;

public class GodslayerDashEffectMobEffect extends MobEffect {
public GodslayerDashEffectMobEffect() {
super(MobEffectCategory.BENEFICIAL, -65281);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.godslayer_dash_effect";
}
@Override public void applyEffectTick(LivingEntity entity, int amplifier) {
GodslayerDashFuncProcedure.execute(entity);
}
@Override public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
super.removeAttributeModifiers(entity, attributeMap, amplifier);
GodslayerDashEffectCoolProcedure.execute(entity);
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
}