

package net.everla.everlatweaker.block;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class ArenaBlockBlock extends
Block
{
public ArenaBlockBlock() {
super( BlockBehaviour.Properties.of()
.instrument(NoteBlockInstrument.BASEDRUM)
.mapColor(MapColor.DEEPSLATE)
.sound(SoundType.NETHERITE_BLOCK)
.strength(-1f, 3600000f)
.lightLevel(s -> 4)
.noOcclusion()
.pushReaction(PushReaction.BLOCK)
.hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
.isRedstoneConductor((bs, br, bp) -> false)
.noLootTable()
);
}
@Override public void appendHoverText(ItemStack itemstack, BlockGetter world, List<Component> list, TooltipFlag flag) {
super.appendHoverText(itemstack, world, list, flag);
}
@Override public float[] getBeaconColorMultiplier(BlockState state, LevelReader world, BlockPos pos, BlockPos beaconPos) {
return new float[] { 0.8f, 0f, 1f };
}
@Override public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
return 15;
}
@Override public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
return Shapes.empty();
}
@Override public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
return
box(0, 0, 0,
16, 15.9, 16)
; }
}