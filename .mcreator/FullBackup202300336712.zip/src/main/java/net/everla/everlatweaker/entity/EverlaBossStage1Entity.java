
package net.everla.everlatweaker.entity;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.sounds.SoundEvent;

import javax.annotation.Nullable;




public class EverlaBossStage1Entity extends Monster  {


	private final ServerBossEvent bossInfo = new ServerBossEvent(this.getDisplayName(),
		ServerBossEvent.BossBarColor.WHITE, ServerBossEvent.BossBarOverlay.PROGRESS);

	public EverlaBossStage1Entity(PlayMessages.SpawnEntity packet, Level world) {
    	this(EverlatweakerModEntities.EVERLA_BOSS_STAGE_1.get(), world);
    }

	public EverlaBossStage1Entity(EntityType<EverlaBossStage1Entity> type, Level world) {
    	super(type, world);
		setMaxUpStep(1f);
		xpReward = 0;
		setNoAi(true);

        	setCustomName(Component.literal("EverlaPrismerAya"));
        	setCustomNameVisible(true);

			setPersistenceRequired();


		this.setPathfindingMalus(BlockPathTypes.WATER, 0);
		this.moveControl = new MoveControl(this) {
			@Override public void tick() {
			    if (EverlaBossStage1Entity.this.isInWater())
                    EverlaBossStage1Entity.this.setDeltaMovement(EverlaBossStage1Entity.this.getDeltaMovement().add(0, 0.005, 0));

				if (this.operation == MoveControl.Operation.MOVE_TO && !EverlaBossStage1Entity.this.getNavigation().isDone()) {
					double dx = this.wantedX - EverlaBossStage1Entity.this.getX();
					double dy = this.wantedY - EverlaBossStage1Entity.this.getY();
					double dz = this.wantedZ - EverlaBossStage1Entity.this.getZ();

					float f = (float) (Mth.atan2(dz, dx) * (double) (180 / Math.PI)) - 90;
					float f1 = (float) (this.speedModifier * EverlaBossStage1Entity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());

					EverlaBossStage1Entity.this.setYRot(this.rotlerp(EverlaBossStage1Entity.this.getYRot(), f, 10));
					EverlaBossStage1Entity.this.yBodyRot = EverlaBossStage1Entity.this.getYRot();
					EverlaBossStage1Entity.this.yHeadRot = EverlaBossStage1Entity.this.getYRot();

					if (EverlaBossStage1Entity.this.isInWater()) {
						EverlaBossStage1Entity.this.setSpeed((float) EverlaBossStage1Entity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());

						float f2 = - (float) (Mth.atan2(dy, (float) Math.sqrt(dx * dx + dz * dz)) * (180 / Math.PI));
						f2 = Mth.clamp(Mth.wrapDegrees(f2), -85, 85);
						EverlaBossStage1Entity.this.setXRot(this.rotlerp(EverlaBossStage1Entity.this.getXRot(), f2, 5));
						float f3 = Mth.cos(EverlaBossStage1Entity.this.getXRot() * (float) (Math.PI / 180.0));

						EverlaBossStage1Entity.this.setZza(f3 * f1);
						EverlaBossStage1Entity.this.setYya((float) (f1 * dy));
					} else {
						EverlaBossStage1Entity.this.setSpeed(f1 * 0.05F);
					}
				} else {
					EverlaBossStage1Entity.this.setSpeed(0);
					EverlaBossStage1Entity.this.setYya(0);
					EverlaBossStage1Entity.this.setZza(0);
				}
			}
		};

	}

	@Override public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}


	@Override protected PathNavigation createNavigation(Level world) {
		return new WaterBoundPathNavigation(this, world);
	}



	@Override public MobType getMobType() {
		return MobType.UNDEFINED;
	}

	@Override public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}


	@Override public double getPassengersRidingOffset() {
		return super.getPassengersRidingOffset() + 1.8;
	}




	@Override public SoundEvent getHurtSound(DamageSource ds) {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.shield.block"));
	}

	@Override public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.shield.break"));
	}



	@Override public boolean hurt(DamageSource damagesource, float amount) {
			double x = this.getX();
			double y = this.getY();
			double z = this.getZ();
			Level world = this.level();
			Entity entity = this;
			Entity sourceentity = damagesource.getEntity();
			Entity immediatesourceentity = damagesource.getDirectEntity();
    

    EverlaBossStage1hurtProcedure.execute(entity)
;
			if (damagesource.is(DamageTypes.IN_FIRE))
				return false;
			if (damagesource.getDirectEntity() instanceof ThrownPotion || damagesource.getDirectEntity() instanceof AreaEffectCloud)
				return false;
			if (damagesource.is(DamageTypes.FALL))
				return false;
			if (damagesource.is(DamageTypes.CACTUS))
				return false;
			if (damagesource.is(DamageTypes.DROWN))
				return false;
			if (damagesource.is(DamageTypes.LIGHTNING_BOLT))
				return false;
			if (damagesource.is(DamageTypes.EXPLOSION))
				return false;
			if (damagesource.is(DamageTypes.FALLING_ANVIL))
				return false;
			if (damagesource.is(DamageTypes.DRAGON_BREATH))
				return false;
			if (damagesource.is(DamageTypes.WITHER))
				return false;
			if (damagesource.is(DamageTypes.WITHER_SKULL))
				return false;
		return super.hurt(damagesource, amount);
	}

	@Override public void die(DamageSource source) {
		super.die(source);
    EverlaBossStage1PhasechangeProcedure.execute(this);
	}










	@Override public boolean checkSpawnObstruction(LevelReader world) {
		return world.isUnobstructed(this);
	}

	@Override public boolean canBreatheUnderwater() {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		return         true
;
	}


	@Override public boolean isPushable() {
		return false;
	}

   	@Override protected void doPush(Entity entityIn) {
   	}

   	@Override protected void pushEntities() {
   	}


	@Override public boolean canChangeDimensions() {
		return false;
	}

	@Override public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		this.bossInfo.addPlayer(player);
	}

	@Override public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		this.bossInfo.removePlayer(player);
	}

	@Override public void customServerAiStep() {
		super.customServerAiStep();
		this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
	}





	public static void init() {

	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.4);
		builder = builder.add(Attributes.MAX_HEALTH, 300);
		builder = builder.add(Attributes.ARMOR, 40);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 30);
		builder = builder.add(Attributes.FOLLOW_RANGE, 16);


		builder = builder.add(Attributes.ATTACK_KNOCKBACK, 2);


		builder = builder.add(ForgeMod.SWIM_SPEED.get(), 0.4);


		return builder;
	}

}
