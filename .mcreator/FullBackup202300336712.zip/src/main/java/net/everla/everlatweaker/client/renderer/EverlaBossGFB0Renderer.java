

package net.everla.everlatweaker.client.renderer;




public class EverlaBossGFB0Renderer extends MobRenderer<EverlaBossGFB0Entity, ModelPlayerModel<EverlaBossGFB0Entity>> {

	public EverlaBossGFB0Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(EverlaBossGFB0Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlaprismer.png");
	}



}
