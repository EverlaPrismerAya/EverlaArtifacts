

package net.everla.everlatweaker.client.renderer;




public class BulletHell2Renderer extends MobRenderer<BulletHell2Entity, ModelBulletModel<BulletHell2Entity>> {

	public BulletHell2Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(BulletHell2Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
