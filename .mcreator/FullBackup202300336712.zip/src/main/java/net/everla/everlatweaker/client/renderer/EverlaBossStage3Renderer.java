

package net.everla.everlatweaker.client.renderer;




public class EverlaBossStage3Renderer extends MobRenderer<EverlaBossStage3Entity, ModelPlayerModel<EverlaBossStage3Entity>> {

	public EverlaBossStage3Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 1.8f);


		this.addLayer(new RenderLayer<EverlaBossStage3Entity, ModelPlayerModel<EverlaBossStage3Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("everlatweaker:textures/entities/overlay.png");

@Override public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light,
EverlaBossStage3Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
}		});
	}


	@Override public ResourceLocation getTextureLocation(EverlaBossStage3Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlaprismer.png");
	}



}
