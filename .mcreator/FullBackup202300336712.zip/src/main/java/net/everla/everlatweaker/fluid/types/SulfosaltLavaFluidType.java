
package net.everla.everlatweaker.fluid.types;

public class SulfosaltLavaFluidType extends FluidType {
public SulfosaltLavaFluidType() {
super(FluidType.Properties.create()
.canSwim(false)
.canDrown(false)
.pathType(BlockPathTypes.LAVA)
.adjacentPathType(null)
.motionScale(0.0035D)
.lightLevel(8)
.density(3000)
.viscosity(5000)
.temperature(1500)
.sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL)
.sound(SoundActions.BUCKET_EMPTY, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.bucket.empty_lava")))
.sound(SoundActions.FLUID_VAPORIZE, SoundEvents.FIRE_EXTINGUISH));
}
@Override public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
consumer.accept(new IClientFluidTypeExtensions() {
private static final ResourceLocation STILL_TEXTURE = new ResourceLocation("everlatweaker:block/sulfosalt_lava_still"),
FLOWING_TEXTURE = new ResourceLocation("everlatweaker:block/sulfosalt_lava_flow");
@Override public ResourceLocation getStillTexture() {
return STILL_TEXTURE;
}
@Override public ResourceLocation getFlowingTexture() {
return FLOWING_TEXTURE;
}
}
);
}
}