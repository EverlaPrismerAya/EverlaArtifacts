package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class GodslayerDashTriggerProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
if (!(entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(EverlatweakerModMobEffects.GODSLAYER_DASH_EFFECT.get()))) {if (!(entity instanceof LivingEntity _livEnt1 && _livEnt1.hasEffect(EverlatweakerModMobEffects.GOD_SLAYER_COOLDOWN.get()))) {if (EverlatweakerModItems.GODSLAYER_ARMOR_BOOTS.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET):ItemStack.EMPTY).getItem()) {if (EverlatweakerModItems.GODSLAYER_ARMOR_LEGGINGS.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS):ItemStack.EMPTY).getItem()) {if (EverlatweakerModItems.GODSLAYER_ARMOR_CHESTPLATE.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST):ItemStack.EMPTY).getItem()) {if (EverlatweakerModItems.GODSLAYER_ARMOR_HELMET.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD):ItemStack.EMPTY).getItem()) {if(entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
_entity.addEffect(new MobEffectInstance(EverlatweakerModMobEffects.GODSLAYER_DASH_EFFECT.get(),15,0));if(entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,20,255));if(entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
_entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,20,255));{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "playsound everlatweaker:godslayerdash master @a ~ ~ ~");
}
}}}}}}}
}
}
