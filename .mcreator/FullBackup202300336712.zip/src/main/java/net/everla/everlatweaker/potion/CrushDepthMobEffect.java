
package net.everla.everlatweaker.potion;

public class CrushDepthMobEffect extends MobEffect {
public CrushDepthMobEffect() {
super(MobEffectCategory.BENEFICIAL, -16764007);
}
@Override public String getDescriptionId() {
return "effect.everlatweaker.crush_depth";
}
@Override public void applyEffectTick(LivingEntity entity, int amplifier) {
CrushDepthDamageProcedure.execute(entity.level(),entity);
}
@Override public boolean isDurationEffectTick(int duration, int amplifier) {
return true;
}
}