

package net.everla.everlatweaker.client.renderer;




public class EverlaBossStage2Renderer extends MobRenderer<EverlaBossStage2Entity, ModelPlayerModel<EverlaBossStage2Entity>> {

	public EverlaBossStage2Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 1.8f);


		this.addLayer(new RenderLayer<EverlaBossStage2Entity, ModelPlayerModel<EverlaBossStage2Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("everlatweaker:textures/entities/overlay.png");

@Override public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light,
EverlaBossStage2Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
}		});
	}


	@Override public ResourceLocation getTextureLocation(EverlaBossStage2Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlaprismer.png");
	}



}
