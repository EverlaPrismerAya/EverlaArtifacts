

package net.everla.everlatweaker.item;

import net.minecraft.world.entity.ai.attributes.Attributes;
import javax.annotation.Nullable;

public class EownssugandromeItem extends Item {
public EownssugandromeItem() {
super(new Item.Properties()
.stacksTo(1)
.rarity(Rarity.EPIC)
.food((new FoodProperties.Builder())
.nutrition(1)
.saturationMod(0.3f)
.alwaysEat()
.build())
);
}
@Override public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
super.appendHoverText(itemstack, world, list, flag);
list.add(Component.literal("text.eown.desc.1"));
list.add(Component.literal("text.eown.desc.2"));
list.add(Component.literal("text.eown.desc.3"));
list.add(Component.literal("text.eown.desc.4"));
list.add(Component.literal("text.eown.desc.5"));
}
@Override public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
ItemStack retval =
super.finishUsingItem(itemstack, world, entity);
double x = entity.getX();
double y = entity.getY();
double z = entity.getZ();
Eown_s_sugandrome_triggerProcedure.execute(entity)
;
return retval;
}
@Override public InteractionResult useOn(UseOnContext context) {
super.useOn(context);
SummonEverlaGFBProcedure.execute(context.getLevel(),context.getClickedPos().getX(),context.getClickedPos().getY(),context.getClickedPos().getZ(),context.getPlayer());
return InteractionResult.SUCCESS;
}
}