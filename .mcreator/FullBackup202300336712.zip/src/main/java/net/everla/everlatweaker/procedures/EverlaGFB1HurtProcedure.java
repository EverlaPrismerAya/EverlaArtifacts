package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class EverlaGFB1HurtProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
boolean found = false;double sx = 0;double sy = 0;double sz = 0;
{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "execute as @p at @s run playsound everlatweaker:gfbhurt master @s ~ ~ ~");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "particle minecraft:end_rod ~ ~1 ~ 0 0 0 0.1 10 normal");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "execute at @p[gamemode=!spectator,distance=..70] run tp @e[type=everlatweaker:everla_boss_gfb_1] ~ ~4 ~");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "spreadplayers ~ ~ 15 15 false @s");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tp ~ ~7 ~");
}
}if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth():-1)<(entity instanceof LivingEntity _livEnt? _livEnt.getMaxHealth():-1)/ 1.5) {if (!(entity.getPersistentData().getBoolean("SummonedWarden")==true)) {{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "summon warden ~ ~ ~ {Tags:[\"summoned_by_everla_gfb\"],Brain:{memories:{\"minecraft:dig_cooldown\":{value:{},ttl:4090L}}},CustomName:'{\"text\":\"\u4F60\u7239\"}'}");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "summon warden ~ ~ ~ {Tags:[\"summoned_by_everla_gfb\"],Brain:{memories:{\"minecraft:dig_cooldown\":{value:{},ttl:4090L}}},CustomName:'{\"text\":\"\u4F60\u7239\"}'}");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "summon warden ~ ~ ~ {Tags:[\"summoned_by_everla_gfb\"],Brain:{memories:{\"minecraft:dig_cooldown\":{value:{},ttl:4090L}}},CustomName:'{\"text\":\"\u4F60\u7239\"}'}");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "summon warden ~ ~ ~ {Tags:[\"summoned_by_everla_gfb\"],Brain:{memories:{\"minecraft:dig_cooldown\":{value:{},ttl:4090L}}},CustomName:'{\"text\":\"\u4F60\u7239\"}'}");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "summon warden ~ ~ ~ {Tags:[\"summoned_by_everla_gfb\"],Brain:{memories:{\"minecraft:dig_cooldown\":{value:{},ttl:4090L}}},CustomName:'{\"text\":\"\u4F60\u7239\"}'}");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tellraw @a[distance=..60] {\"text\":\"<EverlaPrismerAya> \u5927\u54E5\u54E5\u4EEC\u5E2E\u5E2E\u4E03\u53F6\u955C\u7EEB\u5427~\",\"color\":\"light_purple\"}");
}
}entity.getPersistentData().putBoolean("SummonedWarden", true);}}if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth():-1)<(entity instanceof LivingEntity _livEnt? _livEnt.getMaxHealth():-1)/ 2) {if (!(entity.getPersistentData().getBoolean("HalfHealth")==true)) {entity.getPersistentData().putBoolean("HalfHealth", true);{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tellraw @a[distance=..60] {\"text\":\"<EverlaPrismerAya> \u545C\u545C\u545C\u4F60\u6B3A\u8D1F\u4EBA\uFF0C\u4EBA\u5BB6\u8981\u62FF\u5C0F\u624B\u67AA\u6253\u4F60\",\"color\":\"light_purple\"}");
}
}}}if (Math.random()<0.5) {{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "tellraw @a[distance=..60] {\"text\":\"<EverlaPrismerAya> \u4F60\u5C31\u8FD9\u70B9\u52B2\uFF1F\u771F\u662F\u6742\u9C7C\u5462\u2764\",\"color\":\"light_purple\"}");
}
}}
}
}
