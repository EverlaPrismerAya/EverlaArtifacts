

package net.everla.everlatweaker.block;

import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class SulfosaltLavaBlock extends LiquidBlock {
public SulfosaltLavaBlock() {
super(() -> EverlatweakerModFluids.SULFOSALT_LAVA.get(),
BlockBehaviour.Properties.of()
.mapColor(MapColor.FIRE)
.strength(7200f)
.hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true)
.lightLevel(s -> 8)
.noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable()
);
}
@Override public int getFireSpreadSpeed(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
return 5;
}
@Override public void entityInside(BlockState blockstate, Level world, BlockPos pos, Entity entity) {
super.entityInside(blockstate, world, pos, entity);
SulfosaltLavaBurnProcedure.execute(world,entity);
}
}