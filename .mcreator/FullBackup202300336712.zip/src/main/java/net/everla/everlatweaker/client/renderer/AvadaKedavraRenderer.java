

package net.everla.everlatweaker.client.renderer;




public class AvadaKedavraRenderer extends MobRenderer<AvadaKedavraEntity, ModelBulletModel<AvadaKedavraEntity>> {

	public AvadaKedavraRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelBulletModel(context.bakeLayer(ModelBulletModel.LAYER_LOCATION)), 0.5f);


	}


	@Override public ResourceLocation getTextureLocation(AvadaKedavraEntity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/bullet.png");
	}



}
