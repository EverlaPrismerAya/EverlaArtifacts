

package net.everla.everlatweaker.item;

import net.minecraft.world.entity.ai.attributes.Attributes;
import javax.annotation.Nullable;

public class WeirdMintCandyItem extends Item {
public WeirdMintCandyItem() {
super(new Item.Properties()
.stacksTo(1)
.fireResistant()
.rarity(Rarity.EPIC)
.food((new FoodProperties.Builder())
.nutrition(4)
.saturationMod(6f)
.alwaysEat()
.build())
);
}
@Override @OnlyIn(Dist.CLIENT) public boolean isFoil(ItemStack itemstack) {
return true;
}
@Override public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
super.appendHoverText(itemstack, world, list, flag);
list.add(Component.literal("text.weirdcandy.desc.1"));
list.add(Component.literal("text.weirdcandy.desc.2"));
list.add(Component.literal("text.weirdcandy.desc.3"));
list.add(Component.literal("text.weirdcandy.desc.4"));
}
@Override public InteractionResult useOn(UseOnContext context) {
super.useOn(context);
SummonEverlaBossProcedure.execute(context.getLevel(),context.getClickedPos().getX(),context.getClickedPos().getY(),context.getClickedPos().getZ(),context.getPlayer());
return InteractionResult.SUCCESS;
}
}