

package net.everla.everlatweaker.client.renderer;




public class EverlaBossGFBFinalRenderer extends MobRenderer<EverlaBossGFBFinalEntity, ModelPlayerModel<EverlaBossGFBFinalEntity>> {

	public EverlaBossGFBFinalRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 0.5f);


		this.addLayer(new RenderLayer<EverlaBossGFBFinalEntity, ModelPlayerModel<EverlaBossGFBFinalEntity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("everlatweaker:textures/entities/gfboverlay.png");

@Override public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light,
EverlaBossGFBFinalEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
}		});
	}


	@Override public ResourceLocation getTextureLocation(EverlaBossGFBFinalEntity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/leng_meng_.png");
	}



}
