package net.everla.everlatweaker.procedures;

import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;


public class EverlaBossGFBFinalPhaseProcedure {
public static void execute(
Entity entity
) {
if(
entity == null
) return ;
{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "execute as @e[type=everlatweaker:you_cant_escape,limit=1,distance=..60] at @s run summon everlatweaker:everla_boss_gfb_final");
}
}{
Entity _ent = entity;
if(!_ent.level().isClientSide() && _ent.getServer() != null) {
_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(
CommandSource.NULL, _ent.position(), _ent.getRotationVector(),
_ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent
), "effect give @e[type=everlatweaker:everla_boss_gfb_final,distance=..60] resistance 10 255 true");
}
}if(!entity.level().isClientSide()) entity.discard();
}
}
