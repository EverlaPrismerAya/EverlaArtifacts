
package net.everla.everlatweaker.fluid.types;

public class LiquidNitrogenFluidType extends FluidType {
public LiquidNitrogenFluidType() {
super(FluidType.Properties.create()
.fallDistanceModifier(0F)
.canExtinguish(true)
.supportsBoating(true)
.canHydrate(true)
.motionScale(0.0042D)
.density(810)
.viscosity(800)
.temperature(77)
.sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL)
.sound(SoundActions.BUCKET_EMPTY, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.bucket.empty")))
.sound(SoundActions.FLUID_VAPORIZE, SoundEvents.FIRE_EXTINGUISH));
}
@Override public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
consumer.accept(new IClientFluidTypeExtensions() {
private static final ResourceLocation STILL_TEXTURE = new ResourceLocation("everlatweaker:block/liquefied_nitrogen_still"),
FLOWING_TEXTURE = new ResourceLocation("everlatweaker:block/liquefied_nitrogen_flow");
@Override public ResourceLocation getStillTexture() {
return STILL_TEXTURE;
}
@Override public ResourceLocation getFlowingTexture() {
return FLOWING_TEXTURE;
}
}
);
}
}