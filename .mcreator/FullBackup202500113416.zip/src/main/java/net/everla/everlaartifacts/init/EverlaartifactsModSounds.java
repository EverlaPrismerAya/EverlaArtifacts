
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlaartifacts.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.everla.everlaartifacts.EverlaartifactsMod;

public class EverlaartifactsModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, EverlaartifactsMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLABOSSTHEME1 = REGISTRY.register("everlabosstheme1", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everlabosstheme1")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLABOSSTHEME2 = REGISTRY.register("everlabosstheme2", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everlabosstheme2")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLABOSSTHEME3 = REGISTRY.register("everlabosstheme3", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everlabosstheme3")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLABOSSTHEME4 = REGISTRY.register("everlabosstheme4", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everlabosstheme4")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLAFAKEDEATH = REGISTRY.register("everlafakedeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everlafakedeath")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLADEATH = REGISTRY.register("everladeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everladeath")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLABOSSTHEME40 = REGISTRY.register("everlabosstheme40", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everlabosstheme40")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLABOSSTHEME44 = REGISTRY.register("everlabosstheme44", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everlabosstheme44")));
	public static final DeferredHolder<SoundEvent, SoundEvent> BULLSHIT = REGISTRY.register("bullshit", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "bullshit")));
	public static final DeferredHolder<SoundEvent, SoundEvent> LIGHTNING_STORM = REGISTRY.register("lightning_storm", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "lightning_storm")));
	public static final DeferredHolder<SoundEvent, SoundEvent> AVADA_KEDAVRA = REGISTRY.register("avada_kedavra", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "avada_kedavra")));
	public static final DeferredHolder<SoundEvent, SoundEvent> WAAOOO = REGISTRY.register("waaooo", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "waaooo")));
	public static final DeferredHolder<SoundEvent, SoundEvent> TNND = REGISTRY.register("tnnd", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "tnnd")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GENSHIN_START = REGISTRY.register("genshin_start", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "genshin_start")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NOOB = REGISTRY.register("noob", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "noob")));
	public static final DeferredHolder<SoundEvent, SoundEvent> STORM = REGISTRY.register("storm", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "storm")));
	public static final DeferredHolder<SoundEvent, SoundEvent> METAL_PIPE = REGISTRY.register("metal_pipe", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "metal_pipe")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GUN = REGISTRY.register("gun", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "gun")));
	public static final DeferredHolder<SoundEvent, SoundEvent> RELOAD = REGISTRY.register("reload", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "reload")));
	public static final DeferredHolder<SoundEvent, SoundEvent> XELOC = REGISTRY.register("xeloc", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "xeloc")));
	public static final DeferredHolder<SoundEvent, SoundEvent> QUASO = REGISTRY.register("quaso", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "quaso")));
	public static final DeferredHolder<SoundEvent, SoundEvent> IWILLTELLINGYOURDREAM = REGISTRY.register("iwilltellingyourdream",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "iwilltellingyourdream")));
	public static final DeferredHolder<SoundEvent, SoundEvent> HARRYROAD_CYCLONE = REGISTRY.register("harryroad_cyclone", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "harryroad_cyclone")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FUCKYOU = REGISTRY.register("fuckyou", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "fuckyou")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GOHELL = REGISTRY.register("gohell", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "gohell")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FUCKOUT = REGISTRY.register("fuckout", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "fuckout")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GFBHURT = REGISTRY.register("gfbhurt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "gfbhurt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GALATIC_DESTRUCTION = REGISTRY.register("galatic_destruction", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "galatic_destruction")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GLUTINOUS_ARBITRATION = REGISTRY.register("glutinous_arbitration",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "glutinous_arbitration")));
	public static final DeferredHolder<SoundEvent, SoundEvent> VISCOUS_DESPERATION = REGISTRY.register("viscous_desperation", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "viscous_desperation")));
	public static final DeferredHolder<SoundEvent, SoundEvent> TWISTED_GARDEN = REGISTRY.register("twisted_garden", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "twisted_garden")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ICANTREADJAPANESEBRUH = REGISTRY.register("icantreadjapanesebruh",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "icantreadjapanesebruh")));
	public static final DeferredHolder<SoundEvent, SoundEvent> IREALLYWANT2STAYATURHOUSE = REGISTRY.register("ireallywant2stayaturhouse",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "ireallywant2stayaturhouse")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GFBFINALBGM = REGISTRY.register("gfbfinalbgm", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "gfbfinalbgm")));
	public static final DeferredHolder<SoundEvent, SoundEvent> KILLTHEMESSENGER = REGISTRY.register("killthemessenger", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "killthemessenger")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ALEPH_0 = REGISTRY.register("aleph_0", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "aleph_0")));
	public static final DeferredHolder<SoundEvent, SoundEvent> CRUEL_ANGEL = REGISTRY.register("cruel_angel", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "cruel_angel")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DELICATE_WEAPON = REGISTRY.register("delicate_weapon", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "delicate_weapon")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SWEET_DEATH = REGISTRY.register("sweet_death", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "sweet_death")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NEVER_GONNA_GIVE_YOU_UP = REGISTRY.register("never_gonna_give_you_up",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "never_gonna_give_you_up")));
	public static final DeferredHolder<SoundEvent, SoundEvent> HARDEST_2_BE = REGISTRY.register("hardest_2_be", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "hardest_2_be")));
	public static final DeferredHolder<SoundEvent, SoundEvent> REAL_SMOKER = REGISTRY.register("real_smoker", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "real_smoker")));
	public static final DeferredHolder<SoundEvent, SoundEvent> HACKER_GAMER = REGISTRY.register("hacker_gamer", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "hacker_gamer")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FADING_SKY = REGISTRY.register("fading_sky", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "fading_sky")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ELECTRICAL_STICK_BONE = REGISTRY.register("electrical_stick_bone",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "electrical_stick_bone")));
	public static final DeferredHolder<SoundEvent, SoundEvent> LONELY_GUITAR = REGISTRY.register("lonely_guitar", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "lonely_guitar")));
	public static final DeferredHolder<SoundEvent, SoundEvent> ANNOYINGDUMPLING = REGISTRY.register("annoyingdumpling", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "annoyingdumpling")));
	public static final DeferredHolder<SoundEvent, SoundEvent> TWOBREADSANDWICHEDWITHCHEESE = REGISTRY.register("twobreadsandwichedwithcheese",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "twobreadsandwichedwithcheese")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MURASAMA_SWING = REGISTRY.register("murasama_swing", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "murasama_swing")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MURASAMA_SWING_HEAVY = REGISTRY.register("murasama_swing_heavy",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "murasama_swing_heavy")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MURASAMA_HIT_ORGANIC = REGISTRY.register("murasama_hit_organic",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "murasama_hit_organic")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MURASAMA_HIT_INORGANIC = REGISTRY.register("murasama_hit_inorganic",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "murasama_hit_inorganic")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EMOTIONAL_DAMAGE = REGISTRY.register("emotional_damage", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "emotional_damage")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GODSLAYERDASH = REGISTRY.register("godslayerdash", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "godslayerdash")));
	public static final DeferredHolder<SoundEvent, SoundEvent> THE_ONLY_THING_I_KNOW_FOR_REAL = REGISTRY.register("the_only_thing_i_know_for_real",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "the_only_thing_i_know_for_real")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GIRL_GO_TO_LOVE = REGISTRY.register("girl_go_to_love", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "girl_go_to_love")));
	public static final DeferredHolder<SoundEvent, SoundEvent> YAMATO = REGISTRY.register("yamato", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "yamato")));
	public static final DeferredHolder<SoundEvent, SoundEvent> NANOMACHINE = REGISTRY.register("nanomachine", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "nanomachine")));
	public static final DeferredHolder<SoundEvent, SoundEvent> RAIDEN = REGISTRY.register("raiden", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "raiden")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EAGLE_SOUND = REGISTRY.register("eagle_sound", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "eagle_sound")));
	public static final DeferredHolder<SoundEvent, SoundEvent> XELOC_BAD_APPLE = REGISTRY.register("xeloc_bad_apple", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "xeloc_bad_apple")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FIVE_WATT = REGISTRY.register("five_watt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "five_watt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> WORST_APPLE = REGISTRY.register("worst_apple", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "worst_apple")));
	public static final DeferredHolder<SoundEvent, SoundEvent> TOKYO_HOT = REGISTRY.register("tokyo_hot", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "tokyo_hot")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PLACEHOLDER_SND = REGISTRY.register("placeholder_snd", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "placeholder_snd")));
	public static final DeferredHolder<SoundEvent, SoundEvent> GENSHIN_START_SOUND = REGISTRY.register("genshin_start_sound", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "genshin_start_sound")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLA_BLASTER_SHOOT = REGISTRY.register("everla_blaster_shoot",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everla_blaster_shoot")));
	public static final DeferredHolder<SoundEvent, SoundEvent> EVERLA_BLASTER_CHARGE = REGISTRY.register("everla_blaster_charge",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "everla_blaster_charge")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FUCKYOUSTUPIDFLAGANDPRIDE = REGISTRY.register("fuckyoustupidflagandpride",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "fuckyoustupidflagandpride")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DELTARUNE_EXPLOSION = REGISTRY.register("deltarune_explosion", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "deltarune_explosion")));
	public static final DeferredHolder<SoundEvent, SoundEvent> FUMOFUMO = REGISTRY.register("fumofumo", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "fumofumo")));
	public static final DeferredHolder<SoundEvent, SoundEvent> AURIC_STRIKE = REGISTRY.register("auric_strike", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "auric_strike")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MANBO_LEGEND = REGISTRY.register("manbo_legend", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "manbo_legend")));
	public static final DeferredHolder<SoundEvent, SoundEvent> MANBO_NO_MORE = REGISTRY.register("manbo_no_more", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "manbo_no_more")));
	public static final DeferredHolder<SoundEvent, SoundEvent> LONELY_MAN_BROKENHEARTED_SONG = REGISTRY.register("lonely_man_brokenhearted_song",
			() -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("everlaartifacts", "lonely_man_brokenhearted_song")));
}
