
package net.everla.everlaartifacts.potion;

import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.extensions.common.IClientMobEffectExtensions;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.client.gui.screens.inventory.EffectRenderingInventoryScreen;
import net.minecraft.client.gui.GuiGraphics;

import net.everla.everlaartifacts.procedures.WaaoooooProcedure;
import net.everla.everlaartifacts.init.EverlaartifactsModMobEffects;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class WaaoooOverlayMobEffect extends MobEffect {
	public WaaoooOverlayMobEffect() {
		super(MobEffectCategory.HARMFUL, -16776961);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		WaaoooooProcedure.execute(entity);
	}

	@SubscribeEvent
	public static void registerMobEffectExtensions(RegisterClientExtensionsEvent event) {
		event.registerMobEffect(new IClientMobEffectExtensions() {
			@Override
			public boolean isVisibleInInventory(MobEffectInstance effect) {
				return false;
			}

			@Override
			public boolean renderInventoryText(MobEffectInstance instance, EffectRenderingInventoryScreen<?> screen, GuiGraphics guiGraphics, int x, int y, int blitOffset) {
				return false;
			}

			@Override
			public boolean isVisibleInGui(MobEffectInstance effect) {
				return false;
			}
		}, EverlaartifactsModMobEffects.WAAOOO_OVERLAY.get());
	}
}
