package net.everla.everlaartifacts.procedures;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;

public class GenshinStartMobEffectProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Mob _entity)
			_entity.getNavigation().stop();
	}
}
