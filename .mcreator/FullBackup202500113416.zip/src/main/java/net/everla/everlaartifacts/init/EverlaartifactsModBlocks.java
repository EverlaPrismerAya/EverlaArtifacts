
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlaartifacts.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.everla.everlaartifacts.block.NuclearWasteWaterBlock;
import net.everla.everlaartifacts.block.DeepslateAuricOreBlock;
import net.everla.everlaartifacts.block.AuricScrapBlockBlock;
import net.everla.everlaartifacts.EverlaartifactsMod;

public class EverlaartifactsModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EverlaartifactsMod.MODID);
	public static final DeferredBlock<Block> DEEPSLATE_AURIC_ORE = REGISTRY.register("deepslate_auric_ore", DeepslateAuricOreBlock::new);
	public static final DeferredBlock<Block> AURIC_SCRAP_BLOCK = REGISTRY.register("auric_scrap_block", AuricScrapBlockBlock::new);
	public static final DeferredBlock<Block> NUCLEAR_WASTE_WATER = REGISTRY.register("nuclear_waste_water", NuclearWasteWaterBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
