
package net.everla.everlaartifacts.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.everla.everlaartifacts.procedures.GenshinStartSoundPlayProcedure;
import net.everla.everlaartifacts.procedures.GenshinStartMobEffectProcedure;

public class GenshinStartMobEffect extends MobEffect {
	public GenshinStartMobEffect() {
		super(MobEffectCategory.HARMFUL, -1);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		GenshinStartSoundPlayProcedure.execute(entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		GenshinStartMobEffectProcedure.execute(entity);
		return super.applyEffectTick(entity, amplifier);
	}
}
