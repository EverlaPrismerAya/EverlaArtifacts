
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlaartifacts.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.everla.everlaartifacts.item.ZakoUncleItem;
import net.everla.everlaartifacts.item.YamatoItem;
import net.everla.everlaartifacts.item.WorstAppleItem;
import net.everla.everlaartifacts.item.WeirdCocktailItem;
import net.everla.everlaartifacts.item.ViscousDesperationItem;
import net.everla.everlaartifacts.item.TwoBreadSandwichedWithCheeseItem;
import net.everla.everlaartifacts.item.TwistedGardenItem;
import net.everla.everlaartifacts.item.TokyoTicketItem;
import net.everla.everlaartifacts.item.TokyoHotDiscItem;
import net.everla.everlaartifacts.item.ThreeInterwinedFateItem;
import net.everla.everlaartifacts.item.ThousandLoveItem;
import net.everla.everlaartifacts.item.TheonlythingiknowforrealItem;
import net.everla.everlaartifacts.item.SweetDeathItem;
import net.everla.everlaartifacts.item.RedPacketItem;
import net.everla.everlaartifacts.item.RealSmokerItem;
import net.everla.everlaartifacts.item.RawAuricItem;
import net.everla.everlaartifacts.item.RaidenItem;
import net.everla.everlaartifacts.item.PotOfPainItem;
import net.everla.everlaartifacts.item.PayToWinShard5Item;
import net.everla.everlaartifacts.item.PayToWinShard4Item;
import net.everla.everlaartifacts.item.PayToWinShard3Item;
import net.everla.everlaartifacts.item.PayToWinShard2Item;
import net.everla.everlaartifacts.item.PayToWinShard1Item;
import net.everla.everlaartifacts.item.PayToWinCrystalItem;
import net.everla.everlaartifacts.item.NuclearWasteWaterItem;
import net.everla.everlaartifacts.item.NeverGonnaGiveYouUpItem;
import net.everla.everlaartifacts.item.NanomachineItem;
import net.everla.everlaartifacts.item.NanjingTicketItem;
import net.everla.everlaartifacts.item.ManboNoMoreItem;
import net.everla.everlaartifacts.item.ManboLegendItem;
import net.everla.everlaartifacts.item.LonelyManBrokenheartedSongItem;
import net.everla.everlaartifacts.item.LonelyGuitarItem;
import net.everla.everlaartifacts.item.KillTheMessengerItem;
import net.everla.everlaartifacts.item.InnerQuartzOuterNuclearItem;
import net.everla.everlaartifacts.item.IReallyWantToStayAtYourHouseItem;
import net.everla.everlaartifacts.item.Hardest2BeItem;
import net.everla.everlaartifacts.item.HackerGamerItem;
import net.everla.everlaartifacts.item.GlutinousArbitrationItem;
import net.everla.everlaartifacts.item.GirlgotoloveItem;
import net.everla.everlaartifacts.item.GalaticDestructionItem;
import net.everla.everlaartifacts.item.FirecrackerItem;
import net.everla.everlaartifacts.item.FadingSkyItem;
import net.everla.everlaartifacts.item.ElectricalStickBoneItem;
import net.everla.everlaartifacts.item.DelicateWeaponItem;
import net.everla.everlaartifacts.item.CruelAngelItem;
import net.everla.everlaartifacts.item.CondencedPotato9Item;
import net.everla.everlaartifacts.item.CondencedPotato8Item;
import net.everla.everlaartifacts.item.CondencedPotato7Item;
import net.everla.everlaartifacts.item.CondencedPotato6Item;
import net.everla.everlaartifacts.item.CondencedPotato5Item;
import net.everla.everlaartifacts.item.CondencedPotato4Item;
import net.everla.everlaartifacts.item.CondencedPotato3Item;
import net.everla.everlaartifacts.item.CondencedPotato2Item;
import net.everla.everlaartifacts.item.CondencedPotato1Item;
import net.everla.everlaartifacts.item.ChineseDumplingItem;
import net.everla.everlaartifacts.item.ChaliceOfBloodGodItem;
import net.everla.everlaartifacts.item.BraisedPorkWithPlumCabbageItem;
import net.everla.everlaartifacts.item.BeijingTicketItem;
import net.everla.everlaartifacts.item.AuricScrapItem;
import net.everla.everlaartifacts.item.AuricIngotItem;
import net.everla.everlaartifacts.item.Aleph0Item;
import net.everla.everlaartifacts.EverlaartifactsMod;

public class EverlaartifactsModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EverlaartifactsMod.MODID);
	public static final DeferredItem<Item> DEEPSLATE_AURIC_ORE = block(EverlaartifactsModBlocks.DEEPSLATE_AURIC_ORE);
	public static final DeferredItem<Item> RAW_AURIC = REGISTRY.register("raw_auric", RawAuricItem::new);
	public static final DeferredItem<Item> AURIC_SCRAP = REGISTRY.register("auric_scrap", AuricScrapItem::new);
	public static final DeferredItem<Item> AURIC_SCRAP_BLOCK = block(EverlaartifactsModBlocks.AURIC_SCRAP_BLOCK);
	public static final DeferredItem<Item> AURIC_INGOT = REGISTRY.register("auric_ingot", AuricIngotItem::new);
	public static final DeferredItem<Item> ZAKO_UNCLE = REGISTRY.register("zako_uncle", ZakoUncleItem::new);
	public static final DeferredItem<Item> POT_OF_PAIN = REGISTRY.register("pot_of_pain", PotOfPainItem::new);
	public static final DeferredItem<Item> CHINESE_DUMPLING = REGISTRY.register("chinese_dumpling", ChineseDumplingItem::new);
	public static final DeferredItem<Item> RED_PACKET = REGISTRY.register("red_packet", RedPacketItem::new);
	public static final DeferredItem<Item> NUCLEAR_WASTE_WATER_BUCKET = REGISTRY.register("nuclear_waste_water_bucket", NuclearWasteWaterItem::new);
	public static final DeferredItem<Item> INNER_QUARTZ_OUTER_NUCLEAR = REGISTRY.register("inner_quartz_outer_nuclear", InnerQuartzOuterNuclearItem::new);
	public static final DeferredItem<Item> TWO_BREAD_SANDWICHED_WITH_CHEESE = REGISTRY.register("two_bread_sandwiched_with_cheese", TwoBreadSandwichedWithCheeseItem::new);
	public static final DeferredItem<Item> THREE_INTERWINED_FATE = REGISTRY.register("three_interwined_fate", ThreeInterwinedFateItem::new);
	public static final DeferredItem<Item> WEIRD_COCKTAIL = REGISTRY.register("weird_cocktail", WeirdCocktailItem::new);
	public static final DeferredItem<Item> BRAISED_PORK_WITH_PLUM_CABBAGE = REGISTRY.register("braised_pork_with_plum_cabbage", BraisedPorkWithPlumCabbageItem::new);
	public static final DeferredItem<Item> PAY_TO_WIN_SHARD_1 = REGISTRY.register("pay_to_win_shard_1", PayToWinShard1Item::new);
	public static final DeferredItem<Item> PAY_TO_WIN_SHARD_2 = REGISTRY.register("pay_to_win_shard_2", PayToWinShard2Item::new);
	public static final DeferredItem<Item> PAY_TO_WIN_SHARD_3 = REGISTRY.register("pay_to_win_shard_3", PayToWinShard3Item::new);
	public static final DeferredItem<Item> PAY_TO_WIN_SHARD_4 = REGISTRY.register("pay_to_win_shard_4", PayToWinShard4Item::new);
	public static final DeferredItem<Item> PAY_TO_WIN_SHARD_5 = REGISTRY.register("pay_to_win_shard_5", PayToWinShard5Item::new);
	public static final DeferredItem<Item> PAY_TO_WIN_CRYSTAL = REGISTRY.register("pay_to_win_crystal", PayToWinCrystalItem::new);
	public static final DeferredItem<Item> FIRECRACKER = REGISTRY.register("firecracker", FirecrackerItem::new);
	public static final DeferredItem<Item> BEIJING_TICKET = REGISTRY.register("beijing_ticket", BeijingTicketItem::new);
	public static final DeferredItem<Item> NANJING_TICKET = REGISTRY.register("nanjing_ticket", NanjingTicketItem::new);
	public static final DeferredItem<Item> TOKYO_TICKET = REGISTRY.register("tokyo_ticket", TokyoTicketItem::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_1 = REGISTRY.register("condenced_potato_1", CondencedPotato1Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_2 = REGISTRY.register("condenced_potato_2", CondencedPotato2Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_3 = REGISTRY.register("condenced_potato_3", CondencedPotato3Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_4 = REGISTRY.register("condenced_potato_4", CondencedPotato4Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_5 = REGISTRY.register("condenced_potato_5", CondencedPotato5Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_6 = REGISTRY.register("condenced_potato_6", CondencedPotato6Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_7 = REGISTRY.register("condenced_potato_7", CondencedPotato7Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_8 = REGISTRY.register("condenced_potato_8", CondencedPotato8Item::new);
	public static final DeferredItem<Item> CONDENCED_POTATO_9 = REGISTRY.register("condenced_potato_9", CondencedPotato9Item::new);
	public static final DeferredItem<Item> CHALICE_OF_BLOOD_GOD = REGISTRY.register("chalice_of_blood_god", ChaliceOfBloodGodItem::new);
	public static final DeferredItem<Item> GALATIC_DESTRUCTION = REGISTRY.register("galatic_destruction", GalaticDestructionItem::new);
	public static final DeferredItem<Item> GLUTINOUS_ARBITRATION = REGISTRY.register("glutinous_arbitration", GlutinousArbitrationItem::new);
	public static final DeferredItem<Item> VISCOUS_DESPERATION = REGISTRY.register("viscous_desperation", ViscousDesperationItem::new);
	public static final DeferredItem<Item> TWISTED_GARDEN = REGISTRY.register("twisted_garden", TwistedGardenItem::new);
	public static final DeferredItem<Item> THOUSAND_LOVE = REGISTRY.register("thousand_love", ThousandLoveItem::new);
	public static final DeferredItem<Item> I_REALLY_WANT_TO_STAY_AT_YOUR_HOUSE = REGISTRY.register("i_really_want_to_stay_at_your_house", IReallyWantToStayAtYourHouseItem::new);
	public static final DeferredItem<Item> KILL_THE_MESSENGER = REGISTRY.register("kill_the_messenger", KillTheMessengerItem::new);
	public static final DeferredItem<Item> ALEPH_0 = REGISTRY.register("aleph_0", Aleph0Item::new);
	public static final DeferredItem<Item> CRUEL_ANGEL = REGISTRY.register("cruel_angel", CruelAngelItem::new);
	public static final DeferredItem<Item> DELICATE_WEAPON = REGISTRY.register("delicate_weapon", DelicateWeaponItem::new);
	public static final DeferredItem<Item> SWEET_DEATH = REGISTRY.register("sweet_death", SweetDeathItem::new);
	public static final DeferredItem<Item> NEVER_GONNA_GIVE_YOU_UP = REGISTRY.register("never_gonna_give_you_up", NeverGonnaGiveYouUpItem::new);
	public static final DeferredItem<Item> HARDEST_2_BE = REGISTRY.register("hardest_2_be", Hardest2BeItem::new);
	public static final DeferredItem<Item> REAL_SMOKER = REGISTRY.register("real_smoker", RealSmokerItem::new);
	public static final DeferredItem<Item> HACKER_GAMER = REGISTRY.register("hacker_gamer", HackerGamerItem::new);
	public static final DeferredItem<Item> FADING_SKY = REGISTRY.register("fading_sky", FadingSkyItem::new);
	public static final DeferredItem<Item> ELECTRICAL_STICK_BONE = REGISTRY.register("electrical_stick_bone", ElectricalStickBoneItem::new);
	public static final DeferredItem<Item> LONELY_GUITAR = REGISTRY.register("lonely_guitar", LonelyGuitarItem::new);
	public static final DeferredItem<Item> THEONLYTHINGIKNOWFORREAL = REGISTRY.register("theonlythingiknowforreal", TheonlythingiknowforrealItem::new);
	public static final DeferredItem<Item> GIRLGOTOLOVE = REGISTRY.register("girlgotolove", GirlgotoloveItem::new);
	public static final DeferredItem<Item> YAMATO = REGISTRY.register("yamato", YamatoItem::new);
	public static final DeferredItem<Item> NANOMACHINE = REGISTRY.register("nanomachine", NanomachineItem::new);
	public static final DeferredItem<Item> RAIDEN = REGISTRY.register("raiden", RaidenItem::new);
	public static final DeferredItem<Item> WORST_APPLE = REGISTRY.register("worst_apple", WorstAppleItem::new);
	public static final DeferredItem<Item> TOKYO_HOT_DISC = REGISTRY.register("tokyo_hot_disc", TokyoHotDiscItem::new);
	public static final DeferredItem<Item> MANBO_LEGEND = REGISTRY.register("manbo_legend", ManboLegendItem::new);
	public static final DeferredItem<Item> MANBO_NO_MORE = REGISTRY.register("manbo_no_more", ManboNoMoreItem::new);
	public static final DeferredItem<Item> LONELY_MAN_BROKENHEARTED_SONG = REGISTRY.register("lonely_man_brokenhearted_song", LonelyManBrokenheartedSongItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
