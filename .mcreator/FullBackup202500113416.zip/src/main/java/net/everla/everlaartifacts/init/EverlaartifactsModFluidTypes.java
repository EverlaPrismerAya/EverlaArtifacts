
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlaartifacts.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.everla.everlaartifacts.fluid.types.NuclearWasteWaterFluidType;
import net.everla.everlaartifacts.EverlaartifactsMod;

public class EverlaartifactsModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, EverlaartifactsMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> NUCLEAR_WASTE_WATER_TYPE = REGISTRY.register("nuclear_waste_water", () -> new NuclearWasteWaterFluidType());
}
