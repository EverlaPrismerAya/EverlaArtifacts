
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlaartifacts.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.everla.everlaartifacts.fluid.NuclearWasteWaterFluid;
import net.everla.everlaartifacts.EverlaartifactsMod;

public class EverlaartifactsModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, EverlaartifactsMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> NUCLEAR_WASTE_WATER = REGISTRY.register("nuclear_waste_water", () -> new NuclearWasteWaterFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_NUCLEAR_WASTE_WATER = REGISTRY.register("flowing_nuclear_waste_water", () -> new NuclearWasteWaterFluid.Flowing());

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(NUCLEAR_WASTE_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_NUCLEAR_WASTE_WATER.get(), RenderType.translucent());
		}
	}
}
