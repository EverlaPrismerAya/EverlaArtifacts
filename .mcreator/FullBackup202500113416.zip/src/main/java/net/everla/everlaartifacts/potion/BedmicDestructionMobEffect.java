
package net.everla.everlaartifacts.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.everla.everlaartifacts.procedures.BedmicDestructionCheckIfPlayerLookAtBedProcedure;

public class BedmicDestructionMobEffect extends MobEffect {
	public BedmicDestructionMobEffect() {
		super(MobEffectCategory.HARMFUL, -16711783);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		BedmicDestructionCheckIfPlayerLookAtBedProcedure.execute(entity);
		return super.applyEffectTick(entity, amplifier);
	}
}
