
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlaartifacts.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.everla.everlaartifacts.potion.WaaoooOverlayMobEffect;
import net.everla.everlaartifacts.potion.NuclearWaterRadiationMobEffect;
import net.everla.everlaartifacts.potion.GenshinStartMobEffect;
import net.everla.everlaartifacts.potion.BedmicDestructionMobEffect;
import net.everla.everlaartifacts.potion.AmericanStyleCutOverlayMobEffect;
import net.everla.everlaartifacts.EverlaartifactsMod;

public class EverlaartifactsModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, EverlaartifactsMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> NUCLEAR_WATER_RADIATION = REGISTRY.register("nuclear_water_radiation", () -> new NuclearWaterRadiationMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> BEDMIC_DESTRUCTION = REGISTRY.register("bedmic_destruction", () -> new BedmicDestructionMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> GENSHIN_START = REGISTRY.register("genshin_start", () -> new GenshinStartMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> AMERICAN_STYLE_CUT_OVERLAY = REGISTRY.register("american_style_cut_overlay", () -> new AmericanStyleCutOverlayMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> WAAOOO_OVERLAY = REGISTRY.register("waaooo_overlay", () -> new WaaoooOverlayMobEffect());
}
