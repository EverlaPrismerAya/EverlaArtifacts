
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlaartifacts.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.everla.everlaartifacts.EverlaartifactsMod;

public class EverlaartifactsModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, EverlaartifactsMod.MODID);
	public static final DeferredHolder<Potion, Potion> NUCLEAR_WASTE_WATER_BOTTLE = REGISTRY.register("nuclear_waste_water_bottle", () -> new Potion(new MobEffectInstance(EverlaartifactsModMobEffects.NUCLEAR_WATER_RADIATION, 4444, 0, true, true)));
	public static final DeferredHolder<Potion, Potion> FLASHBOMB = REGISTRY.register("flashbomb", () -> new Potion(new MobEffectInstance(EverlaartifactsModMobEffects.GENSHIN_START, 300, 0, false, true)));
}
