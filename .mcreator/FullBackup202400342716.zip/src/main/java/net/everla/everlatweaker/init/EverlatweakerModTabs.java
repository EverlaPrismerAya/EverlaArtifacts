
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlatweaker.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.everla.everlatweaker.EverlatweakerMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EverlatweakerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EverlatweakerMod.MODID);
	public static final RegistryObject<CreativeModeTab> EVERLA_DISCS = REGISTRY.register("everla_discs",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.everlatweaker.everla_discs")).icon(() -> new ItemStack(EverlatweakerModItems.TWISTED_GARDEN.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EverlatweakerModItems.GALATIC_DESTRUCTION.get());
				tabData.accept(EverlatweakerModItems.GLUTINOUS_ARBITRATION.get());
				tabData.accept(EverlatweakerModItems.VISCOUS_DESPERATION.get());
				tabData.accept(EverlatweakerModItems.TWISTED_GARDEN.get());
				tabData.accept(EverlatweakerModItems.THOUSAND_LOVE.get());
				tabData.accept(EverlatweakerModItems.I_REALLY_WANT_TO_STAY_AT_YOUR_HOUSE.get());
				tabData.accept(EverlatweakerModItems.KILL_THE_MESSENGER.get());
				tabData.accept(EverlatweakerModItems.ALEPH_0.get());
				tabData.accept(EverlatweakerModItems.CRUEL_ANGEL.get());
				tabData.accept(EverlatweakerModItems.DELICATE_WEAPON.get());
				tabData.accept(EverlatweakerModItems.SWEET_DEATH.get());
				tabData.accept(EverlatweakerModItems.NEVER_GONNA_GIVE_YOU_UP.get());
				tabData.accept(EverlatweakerModItems.HARDEST_2_BE.get());
				tabData.accept(EverlatweakerModItems.REAL_SMOKER.get());
				tabData.accept(EverlatweakerModItems.HACKER_GAMER.get());
				tabData.accept(EverlatweakerModItems.FADING_SKY.get());
				tabData.accept(EverlatweakerModItems.ELECTRICAL_STICK_BONE.get());
				tabData.accept(EverlatweakerModItems.LONELY_GUITAR.get());
				tabData.accept(EverlatweakerModItems.THEONLYTHINGIKNOWFORREAL.get());
				tabData.accept(EverlatweakerModItems.GIRLGOTOLOVE.get());
				tabData.accept(EverlatweakerModItems.YAMATO.get());
				tabData.accept(EverlatweakerModItems.NANOMACHINE.get());
				tabData.accept(EverlatweakerModItems.RAIDEN.get());
				tabData.accept(EverlatweakerModItems.WORST_APPLE.get());
				tabData.accept(EverlatweakerModItems.TOKYO_HOT_DISC.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> EVERLA_TWEAKER = REGISTRY.register("everla_tweaker",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.everlatweaker.everla_tweaker")).icon(() -> new ItemStack(EverlatweakerModItems.THREE_INTERWINED_FATE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EverlatweakerModBlocks.DEEPSLATE_AURIC_ORE.get().asItem());
				tabData.accept(EverlatweakerModItems.RAW_AURIC.get());
				tabData.accept(EverlatweakerModItems.AURIC_SCRAP.get());
				tabData.accept(EverlatweakerModBlocks.AURIC_SCRAP_BLOCK.get().asItem());
				tabData.accept(EverlatweakerModItems.AURIC_INGOT.get());
				tabData.accept(EverlatweakerModBlocks.EVERLA_DOLL.get().asItem());
				tabData.accept(EverlatweakerModItems.RED_PACKET.get());
				tabData.accept(EverlatweakerModItems.NUCLEAR_WASTE_WATER_BUCKET.get());
				tabData.accept(EverlatweakerModItems.INNER_QUARTZ_OUTER_NUCLEAR.get());
				tabData.accept(EverlatweakerModItems.BEIJING_TICKET.get());
				tabData.accept(EverlatweakerModItems.NANJING_TICKET.get());
				tabData.accept(EverlatweakerModItems.TOKYO_TICKET.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> WEIRD_THING = REGISTRY.register("weird_thing",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.everlatweaker.weird_thing")).icon(() -> new ItemStack(EverlatweakerModItems.BRAISED_PORK_WITH_PLUM_CABBAGE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EverlatweakerModItems.ZAKO_UNCLE.get());
				tabData.accept(EverlatweakerModItems.POT_OF_PAIN.get());
				tabData.accept(EverlatweakerModItems.CHINESE_DUMPLING.get());
				tabData.accept(EverlatweakerModItems.TWO_BREAD_SANDWICHED_WITH_CHEESE.get());
				tabData.accept(EverlatweakerModItems.THREE_INTERWINED_FATE.get());
				tabData.accept(EverlatweakerModItems.WEIRD_COCKTAIL.get());
				tabData.accept(EverlatweakerModItems.BRAISED_PORK_WITH_PLUM_CABBAGE.get());
				tabData.accept(EverlatweakerModItems.PAY_TO_WIN_SHARD_1.get());
				tabData.accept(EverlatweakerModItems.PAY_TO_WIN_SHARD_2.get());
				tabData.accept(EverlatweakerModItems.PAY_TO_WIN_SHARD_3.get());
				tabData.accept(EverlatweakerModItems.PAY_TO_WIN_SHARD_4.get());
				tabData.accept(EverlatweakerModItems.PAY_TO_WIN_SHARD_5.get());
				tabData.accept(EverlatweakerModItems.PAY_TO_WIN_CRYSTAL.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_1.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_2.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_3.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_4.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_5.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_6.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_7.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_8.get());
				tabData.accept(EverlatweakerModItems.CONDENCED_POTATO_9.get());
				tabData.accept(EverlatweakerModItems.CHALICE_OF_BLOOD_GOD.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {

			tabData.accept(EverlatweakerModItems.FIRECRACKER.get());

		}
	}
}
