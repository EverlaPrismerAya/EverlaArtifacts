package net.everla.everlatweaker.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.everla.everlatweaker.init.EverlatweakerModMobEffects;
import net.everla.everlatweaker.EverlatweakerMod;

public class NuclearWaterRadiationEndlessProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		EverlatweakerMod.queueServerWork(1, () -> {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(EverlatweakerModMobEffects.NUCLEAR_WATER_RADIATION.get(), 4444, 0, true, true));
		});
	}
}
