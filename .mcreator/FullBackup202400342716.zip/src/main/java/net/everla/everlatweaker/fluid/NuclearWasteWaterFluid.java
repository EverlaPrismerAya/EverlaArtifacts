
package net.everla.everlatweaker.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.everla.everlatweaker.init.EverlatweakerModItems;
import net.everla.everlatweaker.init.EverlatweakerModFluids;
import net.everla.everlatweaker.init.EverlatweakerModFluidTypes;
import net.everla.everlatweaker.init.EverlatweakerModBlocks;

public abstract class NuclearWasteWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> EverlatweakerModFluidTypes.NUCLEAR_WASTE_WATER_TYPE.get(), () -> EverlatweakerModFluids.NUCLEAR_WASTE_WATER.get(),
			() -> EverlatweakerModFluids.FLOWING_NUCLEAR_WASTE_WATER.get()).explosionResistance(3600f).bucket(() -> EverlatweakerModItems.NUCLEAR_WASTE_WATER_BUCKET.get()).block(() -> (LiquidBlock) EverlatweakerModBlocks.NUCLEAR_WASTE_WATER.get());

	private NuclearWasteWaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.BUBBLE_COLUMN_UP;
	}

	public static class Source extends NuclearWasteWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends NuclearWasteWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
