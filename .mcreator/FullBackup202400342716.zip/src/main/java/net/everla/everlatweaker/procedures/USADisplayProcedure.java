package net.everla.everlatweaker.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.everla.everlatweaker.init.EverlatweakerModMobEffects;

public class USADisplayProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(EverlatweakerModMobEffects.AMERICAN_STYLE_CUT_OVERLAY.get()) ? _livEnt.getEffect(EverlatweakerModMobEffects.AMERICAN_STYLE_CUT_OVERLAY.get()).getDuration() : 0) > 0) {
			return true;
		}
		return false;
	}
}
