
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlatweaker.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.everla.everlatweaker.fluid.types.NuclearWasteWaterFluidType;
import net.everla.everlatweaker.EverlatweakerMod;

public class EverlatweakerModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, EverlatweakerMod.MODID);
	public static final RegistryObject<FluidType> NUCLEAR_WASTE_WATER_TYPE = REGISTRY.register("nuclear_waste_water", () -> new NuclearWasteWaterFluidType());
}
