
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlatweaker.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.everla.everlatweaker.EverlatweakerMod;

public class EverlatweakerModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, EverlatweakerMod.MODID);
	public static final RegistryObject<Potion> NUCLEAR_WASTE_WATER_BOTTLE = REGISTRY.register("nuclear_waste_water_bottle", () -> new Potion(new MobEffectInstance(EverlatweakerModMobEffects.NUCLEAR_WATER_RADIATION.get(), 4444, 0, true, true)));
}
