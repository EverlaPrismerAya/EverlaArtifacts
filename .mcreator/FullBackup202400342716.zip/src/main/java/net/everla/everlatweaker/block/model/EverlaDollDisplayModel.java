package net.everla.everlatweaker.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.everla.everlatweaker.block.display.EverlaDollDisplayItem;

public class EverlaDollDisplayModel extends GeoModel<EverlaDollDisplayItem> {
	@Override
	public ResourceLocation getAnimationResource(EverlaDollDisplayItem animatable) {
		return new ResourceLocation("everlatweaker", "animations/everla_doll.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(EverlaDollDisplayItem animatable) {
		return new ResourceLocation("everlatweaker", "geo/everla_doll.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(EverlaDollDisplayItem entity) {
		return new ResourceLocation("everlatweaker", "textures/block/everla_doll.png");
	}
}
