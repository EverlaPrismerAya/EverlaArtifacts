package net.everla.everlatweaker.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.everla.everlatweaker.block.entity.EverlaDollTileEntity;

public class EverlaDollBlockModel extends GeoModel<EverlaDollTileEntity> {
	@Override
	public ResourceLocation getAnimationResource(EverlaDollTileEntity animatable) {
		return new ResourceLocation("everlatweaker", "animations/everla_doll.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(EverlaDollTileEntity animatable) {
		return new ResourceLocation("everlatweaker", "geo/everla_doll.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(EverlaDollTileEntity entity) {
		return new ResourceLocation("everlatweaker", "textures/block/everla_doll.png");
	}
}
