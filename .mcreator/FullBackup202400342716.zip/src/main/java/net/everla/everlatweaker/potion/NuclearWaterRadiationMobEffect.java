
package net.everla.everlatweaker.potion;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.everla.everlatweaker.procedures.NuclearWaterRadiationEndlessProcedure;
import net.everla.everlatweaker.procedures.NuclearWaterRadiationBuffProcedure;

import java.util.List;
import java.util.ArrayList;

public class NuclearWaterRadiationMobEffect extends MobEffect {
	public NuclearWaterRadiationMobEffect() {
		super(MobEffectCategory.HARMFUL, -16751002);
	}

	@Override
	public List<ItemStack> getCurativeItems() {
		ArrayList<ItemStack> cures = new ArrayList<ItemStack>();
		return cures;
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		NuclearWaterRadiationBuffProcedure.execute(entity);
	}

	@Override
	public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		super.removeAttributeModifiers(entity, attributeMap, amplifier);
		NuclearWaterRadiationEndlessProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
