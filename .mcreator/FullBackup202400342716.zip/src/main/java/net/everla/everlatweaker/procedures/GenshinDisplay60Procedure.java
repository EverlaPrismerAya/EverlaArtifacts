package net.everla.everlatweaker.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.everla.everlatweaker.init.EverlatweakerModMobEffects;

public class GenshinDisplay60Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(EverlatweakerModMobEffects.GENSHIN_START.get()) ? _livEnt.getEffect(EverlatweakerModMobEffects.GENSHIN_START.get()).getDuration() : 0) <= 15) {
			if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(EverlatweakerModMobEffects.GENSHIN_START.get()) ? _livEnt.getEffect(EverlatweakerModMobEffects.GENSHIN_START.get()).getDuration() : 0) > 10) {
				return true;
			}
		}
		return false;
	}
}
