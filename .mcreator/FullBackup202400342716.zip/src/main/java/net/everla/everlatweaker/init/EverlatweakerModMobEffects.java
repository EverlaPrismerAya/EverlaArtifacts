
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.everla.everlatweaker.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.everla.everlatweaker.potion.TableTextCooldownMobEffect;
import net.everla.everlatweaker.potion.NuclearWaterRadiationMobEffect;
import net.everla.everlatweaker.potion.GenshinStartMobEffect;
import net.everla.everlatweaker.potion.BedmicDestructionMobEffect;
import net.everla.everlatweaker.potion.AmericanStyleCutOverlayMobEffect;
import net.everla.everlatweaker.EverlatweakerMod;

public class EverlatweakerModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, EverlatweakerMod.MODID);
	public static final RegistryObject<MobEffect> NUCLEAR_WATER_RADIATION = REGISTRY.register("nuclear_water_radiation", () -> new NuclearWaterRadiationMobEffect());
	public static final RegistryObject<MobEffect> BEDMIC_DESTRUCTION = REGISTRY.register("bedmic_destruction", () -> new BedmicDestructionMobEffect());
	public static final RegistryObject<MobEffect> TABLE_TEXT_COOLDOWN = REGISTRY.register("table_text_cooldown", () -> new TableTextCooldownMobEffect());
	public static final RegistryObject<MobEffect> GENSHIN_START = REGISTRY.register("genshin_start", () -> new GenshinStartMobEffect());
	public static final RegistryObject<MobEffect> AMERICAN_STYLE_CUT_OVERLAY = REGISTRY.register("american_style_cut_overlay", () -> new AmericanStyleCutOverlayMobEffect());
}
