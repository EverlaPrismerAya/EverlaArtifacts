
package net.everla.everlatweaker.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.everla.everlatweaker.entity.EverlaBossGFB0Entity;
import net.everla.everlatweaker.client.model.ModelPlayerModel;

public class EverlaBossGFB0Renderer extends MobRenderer<EverlaBossGFB0Entity, ModelPlayerModel<EverlaBossGFB0Entity>> {
	public EverlaBossGFB0Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(EverlaBossGFB0Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlaprismer.png");
	}
}
