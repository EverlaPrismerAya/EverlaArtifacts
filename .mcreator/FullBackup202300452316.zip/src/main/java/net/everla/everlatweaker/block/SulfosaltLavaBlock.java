
package net.everla.everlatweaker.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.everla.everlatweaker.procedures.SulfosaltLavaBurnProcedure;
import net.everla.everlatweaker.init.EverlatweakerModFluids;

public class SulfosaltLavaBlock extends LiquidBlock {
	public SulfosaltLavaBlock() {
		super(() -> EverlatweakerModFluids.SULFOSALT_LAVA.get(), BlockBehaviour.Properties.of().mapColor(MapColor.FIRE).strength(7200f).hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true).lightLevel(s -> 8).noCollission()
				.noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}

	@Override
	public int getFireSpreadSpeed(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
		return 5;
	}

	@Override
	public void entityInside(BlockState blockstate, Level world, BlockPos pos, Entity entity) {
		super.entityInside(blockstate, world, pos, entity);
		SulfosaltLavaBurnProcedure.execute(world, entity);
	}
}
