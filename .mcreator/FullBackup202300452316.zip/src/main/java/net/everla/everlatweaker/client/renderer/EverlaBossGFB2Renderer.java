
package net.everla.everlatweaker.client.renderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.everla.everlatweaker.procedures.EverlaBossGFB2NormalSkinProcedure;
import net.everla.everlatweaker.procedures.EverlaBossGFB2LumineSkinProcedure;
import net.everla.everlatweaker.entity.EverlaBossGFB2Entity;
import net.everla.everlatweaker.client.model.ModelPlayerModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class EverlaBossGFB2Renderer extends MobRenderer<EverlaBossGFB2Entity, ModelPlayerModel<EverlaBossGFB2Entity>> {
	public EverlaBossGFB2Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelPlayerModel(context.bakeLayer(ModelPlayerModel.LAYER_LOCATION)), 1.8f);
		this.addLayer(new RenderLayer<EverlaBossGFB2Entity, ModelPlayerModel<EverlaBossGFB2Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("everlatweaker:textures/entities/everlalumine.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, EverlaBossGFB2Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (EverlaBossGFB2LumineSkinProcedure.execute(world, x, y, z)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<EverlaBossGFB2Entity, ModelPlayerModel<EverlaBossGFB2Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("everlatweaker:textures/entities/overlay.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, EverlaBossGFB2Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (EverlaBossGFB2NormalSkinProcedure.execute(world, x, y, z)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
		this.addLayer(new RenderLayer<EverlaBossGFB2Entity, ModelPlayerModel<EverlaBossGFB2Entity>>(this) {
			final ResourceLocation LAYER_TEXTURE = new ResourceLocation("everlatweaker:textures/entities/gfboverlay.png");

			@Override
			public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, EverlaBossGFB2Entity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
				Level world = entity.level();
				double x = entity.getX();
				double y = entity.getY();
				double z = entity.getZ();
				if (EverlaBossGFB2LumineSkinProcedure.execute(world, x, y, z)) {
					VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.eyes(LAYER_TEXTURE));
					this.getParentModel().renderToBuffer(poseStack, vertexConsumer, 15728640, LivingEntityRenderer.getOverlayCoords(entity, 0), 1, 1, 1, 1);
				}
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(EverlaBossGFB2Entity entity) {
		return new ResourceLocation("everlatweaker:textures/entities/everlaprismer.png");
	}
}
